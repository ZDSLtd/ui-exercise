// Below JS will show and hide sidebar
$(document).ready(function(){
    $("button").click(function(){
        $("#sidebar-container").toggle(1000);
    });
});